export const targetElements = [".hero-title"];
export const defaultProps = {
  distance: "30px",
  duration: 1000,
  easing: "ease-out",
  origin: "bottom",
  interval: 100,
};
